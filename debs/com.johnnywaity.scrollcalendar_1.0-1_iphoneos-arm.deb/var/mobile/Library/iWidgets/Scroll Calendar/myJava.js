/**
 * Created by Johnny Waity on 2/15/2017.
 */
var date = 15;
var month = 0;
var day = 0;



function initialize() {
    timeSet()
    getMonth()
    getDay()
    dateSet()

}

function timeSet() {
    date = new Date().getDate();
    month = new Date().getMonth();
    var hour = new Date().getHours();
    var min = new Date().getMinutes();
    day = new Date().getDay();

    document.getElementById("Date").innerHTML = date
}
function getMonth() {
    if (month === 0){
        document.getElementById("Month").innerHTML = "January"
    }
    else if (month === 1){
        document.getElementById("Month").innerHTML = "February"
    }
    else if (month === 2){
        document.getElementById("Month").innerHTML = "March"
    }
    else if (month === 3){
        document.getElementById("Month").innerHTML = "April"
    }
    else if (month === 4){
        document.getElementById("Month").innerHTML = "May"
    }
    else if (month === 5){
        document.getElementById("Month").innerHTML = "June"
    }
    else if (month === 6){
        document.getElementById("Month").innerHTML = "July"
    }
    else if (month === 7){
        document.getElementById("Month").innerHTML = "August"
    }
    else if (month === 8){
        document.getElementById("Month").innerHTML = "September"
    }
    else if (month === 9){
        document.getElementById("Month").innerHTML = "October"
    }
    else if (month === 10){
        document.getElementById("Month").innerHTML = "November"
    }
    else if (month === 11){
        document.getElementById("Month").innerHTML = "December"
    }
}


function getDay() {
    if (day === 0){
        document.getElementById("Day").innerHTML = "Sunday"
    }
    else if (day === 1){
        document.getElementById("Day").innerHTML = "Monday"
    }
    else if (day === 2){
        document.getElementById("Day").innerHTML = "Tuesday"
    }
    else if (day === 3){
        document.getElementById("Day").innerHTML = "Wednesday"
    }
    else if (day === 4){
        document.getElementById("Day").innerHTML = "Thursday"
    }
    else if (day === 5){
        document.getElementById("Day").innerHTML = "Friday"
    }
    else if (day === 6){
        document.getElementById("Day").innerHTML = "Saturday"
    }
}


function dateSet() {
    if (date>1){
        // alert()
        var one = date-1
        document.getElementById("Before1").innerHTML = one
        var two = date-2
        document.getElementById("Before2").innerHTML = two
        var three = date-3
        document.getElementById("Before3").innerHTML = three

    }
    if (date<30){
        var one1 = date+3
        document.getElementById("After1").innerHTML = one1
        var two1 = date+2
        document.getElementById("After2").innerHTML = two1
        var three1 = date+1
        document.getElementById("After3").innerHTML = three1
    }
}