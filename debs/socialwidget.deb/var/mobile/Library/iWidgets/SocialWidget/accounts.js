/**
 * Created by Johnny Waity on 3/5/2017.
 */

//Twitter Username
var twitter = 'johnnyjwaity';


//Youtube Channel ID (NOT CHANNEL NAME!!)
var youtube = 'UCJWs3s5UKm2cLTTAuqqP3JQ';


//instagram username
var instagram = 'johnnywaity';


//Color Theme. 0 for white background. 1 for black background. 2 for transparent background and black text. 3 for transparent background and white text
var theme = 0;

