/**
 * Created by Johnny Waity on 3/5/2017.
 */


function init() {
    var color = 'white'
    if (theme === 0){
        color = 'white'
        document.getElementById("youtube").style.color = 'black'
        document.getElementById("twitter").style.color = 'black'
        document.getElementById("instagram").style.color = 'black'

    }
    else if (theme === 1){
        color = 'black'
        document.getElementById("youtube").style.color = 'white'
        document.getElementById("twitter").style.color = 'white'
        document.getElementById("instagram").style.color = 'white'

    }
    else if (theme === 2){
        color = 'transparent'
        document.getElementById("youtube").style.color = 'black'
        document.getElementById("twitter").style.color = 'black'
        document.getElementById("instagram").style.color = 'black'

    }
    else if (theme === 3){
        color = 'transparent'
        document.getElementById("youtube").style.color = 'white'
        document.getElementById("twitter").style.color = 'white'
        document.getElementById("instagram").style.color = 'white'

    }

    document.getElementById("wrapper").style.backgroundColor = color
    setInterval(refresh(), 600000)
}



function refresh() {
    tname = twitter;
    var dataString = 'tuser='+tname;

    $.ajax({
        type: "POST",
        url: "http://johnnywaity.com/twitterFollow.php",
        data: dataString,
        cache: false,
        success: function (result) {
            document.getElementById("twitter").innerHTML = result
        },
        error: function () {
            alert("Error")
        }


    });
    ytid = youtube;
    dataString = 'tuser='+ytid;

    $.ajax({
        type: "POST",
        url: "http://johnnywaity.com/ytcount.php",
        data: dataString,
        cache: false,
        success: function (result) {
            document.getElementById("youtube").innerHTML = result
        },
        error: function () {
            alert("Error")
        }


    });

    insta = instagram;
    dataString = 'tuser='+insta;

    $.ajax({
        type: "POST",
        url: "http://johnnywaity.com/ytname.php",
        data: dataString,
        cache: false,
        success: function (result) {
            document.getElementById("instagram").innerHTML = result
        },
        error: function () {
            alert("Error")
        }


    })




}

